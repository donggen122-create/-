# 에셋 출처 및 라이선스

이 문서는 `game/assets/`에 실제로 포함된 외부 에셋의 출처를 기록한다. 모든 파일은 아래 원본 페이지에서
**직접 다운로드해 프로젝트에 포함**했으며, 외부 URL을 코드에서 직접 참조하지 않는다.

## 그래픽 — Kenney "Tiny Dungeon"

- 제작자: Kenney (www.kenney.nl)
- 원본 페이지: https://kenney.nl/assets/tiny-dungeon
- 라이선스: CC0 1.0 (Creative Commons Zero — 저작권 없음, 상업적 사용/재배포/2차 수정 자유, 크레딧 의무 없음)
- 다운로드 파일: `kenney_tiny-dungeon.zip` (2022-07-05 릴리즈), `game/assets_src/tiny-dungeon/License.txt`에 원본 라이선스 텍스트 보관
- 수정 여부: 개별 16×16 타일을 그대로 사용(리사이즈 없음). 게임 내에서 **색조 틴트(canvas source-atop 합성)** 로 재채색해 사용한 곳이 있음(아래 매핑 표 "수정" 열 참조). 크롭·확대·이어붙임 등은 하지 않았다.

### 콘텐츠 ID ↔ 에셋 매핑

| 게임 요소 | 원본 타일 | 저장 파일명 | 수정 |
|---|---|---|---|
| 플레이어(파수꾼) | tile_0096 (파랑 갑옷 기사) | `sprites/player_knight.png` | 없음 |
| EN01 그림자 잔해 | tile_0121 (유령) | `sprites/enemy_wraith.png` | 런타임 보라색 틴트 |
| EN02 황혼 들개 | tile_0122 (거미) | `sprites/enemy_spider.png` | 런타임 강청색 틴트 (원작에 개 스프라이트가 없어 실루엣이 뚜렷한 거미로 대체 — 아래 "남은 대체/재해석" 참고) |
| EL01 거대 잔해(엘리트) | tile_0120 (박쥐형 마물) | `sprites/enemy_elite.png` | 런타임 적색 틴트 + 확대(1.6배) + 외곽 발광 |
| 봉화/장식 횃불 | tile_0029 (횃불) | `sprites/prop_torch.png` | 없음(코드로 깜빡임·발광 애니메이션 추가) |
| 배경 장식 바위 | tile_0024 (돌벽) | `sprites/prop_rock.png` | 없음 |
| 보물 상자(접근 시 골드 지급) | tile_0033 (상자) | `sprites/prop_chest.png` | 없음(개봉 후 어둡게 틴트) |
| 바닥 타일 | tile_0050 (흙바닥) | `sprites/floor_ground.png` | 없음(반복 타일링) |
| (미사용, 예비) | tile_0109 (임프) | `sprites/enemy_imp.png` | 향후 챕터 확장용으로 보관, 이번 적용에는 미사용 |

## UI 프레임 — Kenney "Fantasy UI Borders"

- 원본 페이지: https://kenney.nl/assets/fantasy-ui-borders
- 라이선스: CC0 1.0
- 사용 파일: `panel-border-006.png`→`ui/panel-border.png`(메인 패널), `panel-border-004.png`→`ui/panel-border-thin.png`(레벨업 카드)
- 수정 여부: 없음(원본은 흰색 선화이며, CSS `filter`로 톤만 조절해 사용. 파일 자체는 무수정)

## 효과음 — Kenney "RPG Audio" / "UI Audio" / "Impact Sounds"

- 원본 페이지: https://kenney.nl/assets/rpg-audio , https://kenney.nl/assets/ui-audio , https://kenney.nl/assets/impact-sounds
- 라이선스: 모두 CC0 1.0
- 수정 여부: 없음(원본 OGG 그대로, 파일명만 용도에 맞게 변경)

| 게임 상황 | 원본 파일 | 저장 파일명 |
|---|---|---|
| 공격 발사 | RPG Audio `cloth1.ogg` | `audio/attack_whoosh.ogg` |
| (예비) 근접 공격 | RPG Audio `knifeSlice.ogg` | `audio/attack_slice.ogg` |
| 적 피격 | Impact Sounds `impactGeneric_light_000/002.ogg` | `audio/hit_light.ogg`, `hit_light2.ogg` |
| 엘리트/보스 피격 | Impact Sounds `impactBell_heavy_001.ogg` | `audio/hit_boss.ogg` |
| 경험치 보석 획득 | RPG Audio `metalClick.ogg` | `audio/gem_pickup.ogg` |
| 골드/보상 지급(결과 화면) | RPG Audio `handleCoins.ogg` | `audio/gold_reward.ogg` |
| 보스 패턴 예고 | RPG Audio `creak2.ogg` | `audio/boss_telegraph.ogg` |
| 레벨업 카드 등장 | UI Audio `switch7.ogg` | `audio/levelup_open.ogg` |
| 카드/버튼 선택 | UI Audio `switch14.ogg` | `audio/card_select.ogg` |
| 일반 버튼 클릭 | UI Audio `click2.ogg` | `audio/ui_click.ogg` |

## 자체(코드) 제작 — 이미지 생성 도구 미사용

이 세션에는 이미지 생성 도구가 연결되어 있지 않아, 이미지 생성 도구를 사용했다고 표기하지 않는다.
아래는 전부 Canvas 2D 코드로 절차적으로 그린 것이다(래스터 이미지 파일 없음):

- **보스 BS01 황혼의 거목**: 어울리는 "황혼의 고목 몬스터" 공개 스프라이트를 찾지 못해 트렁크+가지+캐노피+발광하는 눈을 코드로 직접 그림(가지 흔들림·2페이즈 색 변화 애니메이션 포함).
- 경험치 보석(빛나는 결정), 투사체 및 궤적(발광 오브+trail), 피격 섬광, 사망 파티클, 레벨업 카드 등장 이펙트, 보스 패턴 예고(원형 균열/부채꼴 경고/방사형 경고선), 봉화 불빛 확산(radial gradient), 바닥 비네트.

## 남은 대체/재해석 (정직한 고지)

- EN02(황혼 들개)는 원작 기획의 "개" 실루엣 에셋을 공개 팩에서 찾지 못해 거미(tile_0122)로 대체했다. 추후 반려동물/몬스터 팩을 추가로 조사해 교체할 수 있다.
- 캐릭터 12종 중 1종(파수꾼 기사)만 그래픽이 있다. 나머지 11종은 아직 미구현(로직 자체가 없음, STATUS.md 참조).
- 배경은 반복 타일 1종 + 장식 소품(바위·횃불, 순수 연출)과 상호작용 가능한 보물 상자(접근 시 골드 1회 지급)이며, CH01 데이터의 "어둠 지대 없음"에 맞춰 어둠 연출은 넣지 않았다. 봉화 조명(광원 확산)만 장식으로 배치했다.
- 진화/융합 카드, 상태 이상 아이콘 등은 로직 자체가 아직 없어 그래픽도 없다.
