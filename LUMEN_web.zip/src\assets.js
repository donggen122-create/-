// 에셋 매니페스트 — 콘텐츠 ID와 실제 파일을 한곳에서 연결한다.
// 출처는 ASSET_CREDITS.md 참조. 이미지 크기(16x16 원본)와 게임 내 표시/충돌 크기는 분리되어 있으며,
// 표시 크기는 content.js의 각 정의(radiusU 등)가, 확대 배율은 아래 DRAW_SCALE이 담당한다.

const IMG_BASE = "./assets/sprites/";
const AUDIO_BASE = "./assets/audio/";
const UI_BASE = "./assets/ui/";

export const SPRITE_FILES = {
  player_knight: IMG_BASE + "player_knight.png",
  enemy_wraith: IMG_BASE + "enemy_wraith.png",
  enemy_spider: IMG_BASE + "enemy_spider.png",
  enemy_elite: IMG_BASE + "enemy_elite.png",
  prop_torch: IMG_BASE + "prop_torch.png",
  prop_rock: IMG_BASE + "prop_rock.png",
  prop_chest: IMG_BASE + "prop_chest.png",
  floor_ground: IMG_BASE + "floor_ground.png",
};

export const UI_FILES = {
  panelBorder: UI_BASE + "panel-border.png",
  panelBorderThin: UI_BASE + "panel-border-thin.png",
};

export const SFX_FILES = {
  attackFire: AUDIO_BASE + "attack_whoosh.ogg",
  hitLight: AUDIO_BASE + "hit_light.ogg",
  hitLight2: AUDIO_BASE + "hit_light2.ogg",
  hitBoss: AUDIO_BASE + "hit_boss.ogg",
  gemPickup: AUDIO_BASE + "gem_pickup.ogg",
  goldReward: AUDIO_BASE + "gold_reward.ogg",
  bossTelegraph: AUDIO_BASE + "boss_telegraph.ogg",
  levelupOpen: AUDIO_BASE + "levelup_open.ogg",
  cardSelect: AUDIO_BASE + "card_select.ogg",
  uiClick: AUDIO_BASE + "ui_click.ogg",
};

const imageCache = {};
export function loadImage(src) {
  if (imageCache[src]) return imageCache[src];
  const img = new Image();
  img.src = src;
  imageCache[src] = img;
  return img;
}

export const SPRITES = Object.fromEntries(
  Object.entries(SPRITE_FILES).map(([k, v]) => [k, loadImage(v)])
);
export const UI_IMAGES = Object.fromEntries(
  Object.entries(UI_FILES).map(([k, v]) => [k, loadImage(v)])
);

// ---- 색조 틴트 (source-atop 합성) — 같은 원본 스프라이트를 콘텐츠별로 재채색 ----
const tintCache = {};
export function tintedSprite(img, colorRgba, key) {
  const cacheKey = key || (img.src + colorRgba);
  if (tintCache[cacheKey]) return tintCache[cacheKey];
  const w = img.naturalWidth || 16, h = img.naturalHeight || 16;
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const cx = c.getContext("2d");
  const draw = () => {
    cx.clearRect(0, 0, w, h);
    cx.drawImage(img, 0, 0, w, h);
    cx.globalCompositeOperation = "source-atop";
    cx.fillStyle = colorRgba;
    cx.fillRect(0, 0, w, h);
    cx.globalCompositeOperation = "source-over";
  };
  if (img.complete && img.naturalWidth) draw();
  else img.addEventListener("load", () => { c.width = img.naturalWidth; c.height = img.naturalHeight; draw(); }, { once: true });
  tintCache[cacheKey] = c;
  return c;
}

// ---- 효과음: Web Audio API ----
// <audio> 엘리먼트를 복제해 재생하면 동시 타격이 많을 때 Chrome의 WebMediaPlayer 개수 한도
// ("too many WebMediaPlayers")에 걸려 소리가 끊긴다. 짧은 SFX는 AudioBuffer 한 번만 디코딩해두고
// 재생할 때마다 가벼운 BufferSource를 만드는 방식이 정석이라 그렇게 처리한다.
const MUTE_KEY = "lumen_muted";
let muted = localStorage.getItem(MUTE_KEY) === "1";

let audioCtx = null;
let masterGain = null;
const bufferCache = {};   // name -> AudioBuffer
const pendingLoads = {};  // name -> Promise
const lastPlayedAt = {};  // name -> timestamp (연타 스팸 방지)
const MIN_GAP_MS = 45;    // 같은 효과음 최소 간격
let activeVoices = 0;
const MAX_VOICES = 24;

function ensureCtx() {
  if (audioCtx) return audioCtx;
  const Ctx = window.AudioContext || window.webkitAudioContext;
  if (!Ctx) return null;
  audioCtx = new Ctx();
  masterGain = audioCtx.createGain();
  masterGain.gain.value = 1;
  masterGain.connect(audioCtx.destination);
  return audioCtx;
}

function loadBuffer(name) {
  if (bufferCache[name]) return Promise.resolve(bufferCache[name]);
  if (pendingLoads[name]) return pendingLoads[name];
  const ctx = ensureCtx();
  if (!ctx) return Promise.resolve(null);
  pendingLoads[name] = fetch(SFX_FILES[name])
    .then((r) => r.arrayBuffer())
    .then((buf) => ctx.decodeAudioData(buf))
    .then((decoded) => { bufferCache[name] = decoded; return decoded; })
    .catch(() => null);
  return pendingLoads[name];
}

// 첫 사용자 입력 시 오디오 컨텍스트를 깨우고 전체 프리로드(자동재생 정책 대응)
function primeAudio() {
  const ctx = ensureCtx();
  if (!ctx) return;
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  for (const name in SFX_FILES) loadBuffer(name);
}
window.addEventListener("pointerdown", primeAudio, { once: true });
window.addEventListener("keydown", primeAudio, { once: true });

export function playSfx(name, volume = 0.6) {
  if (muted) return;
  const now = performance.now();
  if (lastPlayedAt[name] && now - lastPlayedAt[name] < MIN_GAP_MS) return;
  if (activeVoices >= MAX_VOICES) return;
  const ctx = ensureCtx();
  if (!ctx) return;
  const buf = bufferCache[name];
  if (!buf) { loadBuffer(name); return; } // 아직 디코딩 전이면 이번 재생은 건너뛴다
  lastPlayedAt[name] = now;
  try {
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = volume;
    src.connect(g); g.connect(masterGain);
    activeVoices++;
    src.onended = () => { activeVoices--; src.disconnect(); g.disconnect(); };
    src.start();
  } catch (e) { /* 재생 실패는 게임 진행에 영향 없음 */ }
}
export function isMuted() { return muted; }
export function setMuted(v) {
  muted = v;
  localStorage.setItem(MUTE_KEY, v ? "1" : "0");
  if (masterGain) masterGain.gain.value = v ? 0 : 1;
  if (!v) primeAudio();
}
export function toggleMuted() { setMuted(!muted); return muted; }
