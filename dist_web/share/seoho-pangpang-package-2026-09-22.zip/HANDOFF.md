# 서호팡팡수호대 — 세션 인수인계 (2026-09-22 기준)

## 한 줄 요약
서호초등학교 학생(약 100명)용 브라우저 탑다운 서바이벌 액션 게임. 원래 기획명 LUMEN(황혼의 파수꾼)에서 이름·주제를 바꿔 **"서호팡팡수호대 — 마을의 환경을 지켜라"**(생태·환경 주제)로 전환 중. 실서버에 배포되어 있고 학생 계정(아이디·비번만)으로 서버 저장한다.

- **실서버(학생용 주소)**: https://seoho-pangpang.seoho-pangpang-server.workers.dev
- 사용자는 개발자가 아니다. 한국어, 쉬운 말, 결과는 화면(스크린샷·실서버)으로 확인해 보여 주기.
- 진행 기록은 `game/STATUS.md`(최신이 위) — 작업 후 반드시 갱신.

## 폴더
| 경로 | 내용 |
|---|---|
| `game/` | **소스**. `index.html`, `src/*.js`(ES 모듈, 빌드 없음), `assets/`(그림·소리·글꼴), `tools/`(스크립트), `STATUS.md`, `ASSET_CREDITS.md` |
| `dist_web/` | 배포 사본 = `game/`의 index.html·src·assets를 복사한 것. **서버가 이 폴더를 서빙**한다. 수정 후 반드시 동기화 |
| `dist_single/LUMEN.html` | 단일 파일판(모든 것 data URI). `game/tools/build-single.ps1`로 생성. 열면 실서버 API에 붙음(인터넷 필요) |
| `server/` | Cloudflare Worker(`src/index.js`) + D1 스키마(`schema.sql`) + `wrangler.toml` + README(배포 절차) |
| `이미지 에셋/` | 사용자가 Gemini 앱으로 만든 원본 그림(주인공 시트, 시작 화면 배경, 엠블럼, 마스코트, 테마 1 그림) + `필요한_그림_목록.md` |
| `dist_web/share/` | **ChatGPT 협업용 공개 자료**(브리핑·문서·데이터·전체 zip). 실서버 `/share/`로 서빙. `GPT_협업_브리핑.md`(루트)가 원본. 갱신은 STATUS 00000000 참조 |
| `data/`, `docs/` | 원 기획서 CSV/JSON·문서 19장. `data` → `game/tools/build-content.ps1` → `game/src/content.data.js` |

## 실행·배포 명령 (PowerShell 5.1, 프로젝트 루트에서)
```powershell
# Node·Python은 PATH에 없다 → 세션마다 앞에 붙이기
$env:Path = "C:\Users\user\AppData\Local\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.19.0-win-x64;$env:Path"
$py = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"   # Pillow, numpy, scipy, fonttools, brotli 설치됨

# 게임 수정 → 배포본 동기화 → 실서버 배포 (wrangler 로그인은 이 PC에 이미 되어 있음)
Copy-Item game\src\*.js dist_web\src\ -Force; Copy-Item game\index.html dist_web\ -Force   # assets 바뀌면 그것도
Push-Location server; npx wrangler deploy; Pop-Location

# 로컬 테스트: 게임+API 한 번에 (로컬 D1은 wrangler.toml의 database_id별로 생김 → 처음/ID 변경 후 스키마 넣기)
Push-Location server; npx wrangler d1 execute seoho-pangpang-db --local --file=schema.sql; npx wrangler dev --port 8797 --local
# 정적만: powershell -File game\server.ps1 -Port 8796  (.claude/launch.json "lumen")

# 단일 파일판
powershell -NoProfile -ExecutionPolicy Bypass -File game\tools\build-single.ps1
```
- 실서버 D1: `seoho-pangpang-db`(APAC). 운영 쿼리: `npx wrangler d1 execute seoho-pangpang-db --remote --command "SELECT COUNT(*) FROM users"`
- 실서버에 **계정은 아직 0개**(테스트 계정은 로컬 DB에만 있었고 지워짐).

## 현재 구현 상태 (핵심)
- **시작 화면**: 배경 일러스트(세로/가로 자동), 무궁화 '서호' 엠블럼, 제목(Jua 글꼴 부분 추출), 호야·민지 응원 포즈(넓은 화면은 양옆 absolute, 좁은 화면은 카드 양옆 작게), 새싹 지구 마스코트(호야 머리 위), 접속 카드.
- **서버 필수**: 기기 전용 모드 없음. `src/cloud.js`가 API를 ①localStorage `lumen_api` → ②같은 주소 `/api` → ③실서버 고정 주소 순으로 찾음. 접속 후 서버 저장본 우선, 없으면 기기 진행 업로드. `writeSave`마다 2초 뒤 업로드(로비 우상단 ☁). 토큰 `lumen_token`.
- **API**(`server/src/index.js`): register/login/me/logout/save(GET·PUT). 비번 PBKDF2-SHA256 12k회. 제한: IP당 로그인 300/10분·가입 100/시간, 같은 아이디 비번 10회 연속 실패 → 15분 잠금.
- **주인공**: 호야/민지 중 처음 한 번만 선택(`save.hero`, 변경 버튼 없음). 프레임 애니메이션(서기/걷기3/달리기3/점프/공격3/피격/쓰러짐) `assets/sprites/heroes/`, 서 있기 키 112px 통일(`HERO_DRAW_H=77`). 겉모습만 바뀌고 능력은 기존 캐릭터(C01~C12)가 담당.
- **스테이지 1~30 서바이벌**(`SURVIVAL_CHAPTERS=30`): 5분 카운트다운, 버티면 클리어. 각 장의 5단계(CH05·10·…)는 시간 종료 시 보스 등장 → 처치해야 클리어. CH31~는 기존 방식.
- **로비(2026-09-22 개편, 밝은 테마)**: 탭 5개 모험/대원/가방/임무/상점. 모험 탭 = 내 대원 카드 + 환경 이야기 카드 + 모험 지도(현재 장의 5단계 카드, 출동! 버튼). 장·단계 이름·환경 이야기는 `src/themes.js`(6장×5단계, chapters 데이터는 그대로). 놀이 모드·빠른 전투·봉화 수익 버튼·부품·프리셋·이벤트·모드 상점·재화 4종은 **숨김**(코드 유지, STATUS 00000 참조). 봉화 수익은 로비 입장 시 자동 수령.
- **일시정지**: Esc/⏸ → 계속·로비로·처음 화면으로(나가기 = 패배 정리). 로비 🏠 = 처음 화면.
- 문구: 시작 화면·로비 "마을의 환경을 지켜라". 로비는 쉬운 말(출동!, 성공/도전 전, 대원, 가방…)로 바꿨지만 게임 데이터 용어(봉화·어둠 지대·광휘·파수꾼·금화 등)와 전투·결과 화면은 아직 옛 세계관·어두운 스타일.
- **환경 테마 기획안**(6장: 쓰레기 마을 → 더러워진 개울 → 뿌연 하늘 → 불타는 숲 → 플라스틱 바다 → 뜨거운 지구)은 사용자 승인. **테마 1 「쓰레기 마을」은 구현·배포됨**(STATUS 000000): 그림은 `이미지 에셋/` → `game/tools/cut_theme1.py` → `game/assets/sprites/t1/`, 적·보스·단계 구성은 `src/themes.js`(T1_*), `content.js` 끝에서 CH01~05에 덮어씀. 테마 2 이후는 같은 방식으로: 그림 목록·프롬프트 `이미지 에셋/필요한_그림_목록.md`(전체 목록의 바닥·소품 + 적·보스 시트 추가 요청), `cut_theme1.py`를 복사해 상자 좌표만 바꾸고, themes.js에 T2_* 표를 추가.
- claude.ai 아티팩트 링크는 서버 통신이 막혀 쓸 수 없음 → 사용자가 직접 삭제 예정. 더 갱신하지 말 것.

## 도구·함정
- **PowerShell 스크립트에 한글이 있으면 UTF-8 BOM으로 저장**(없으면 깨져서 실패). `Remove-Item 경로\*.png`가 가끔 차단됨 → `Copy-Item -Force`로 덮어쓰기.
- `Invoke-RestMethod`는 TLS1.2 설정 + UTF-8 바이트 본문 필요(한글 JSON). 실서버 확인은 `curl.exe`도 가능.
- 브라우저 패널은 `file://`를 못 연다 → 단일 파일 테스트는 `game/zz_*.html`로 복사해 8796으로 열고 지우기.
- **Gemini 앱 이미지**: 같은 채팅에서 이어 요청하면 이전 그림을 "편집"해 회색 캔버스가 나옴 → **이미지마다 새 채팅**, "이전 이미지를 편집하지 말고 새로 생성" 문구. 다운로드 파일이 깨지면 우클릭 저장(1024px)으로 대체. 배경은 마젠타(#FF00FF)/초록(#00FF00) 단색으로 요청 → `cut_heroes.py`(시트) / `cut_title_art.py`(단일 그림) 크로마키. 마젠타 키는 `min(R,B)-G`(분홍 보호), 분홍 글로우는 가장자리 연결 영역 제거(flood).
- 제목 글꼴은 부분 추출(266자, 39KB). **시작 화면·로비 제목 문구를 바꾸면 `python game/tools/subset_font.py` 재실행**(JS 문구는 스크립트의 `JS_STRINGS`에 추가). 임의 문자열(아이디)은 `.sysfont`로.
- `build-single.ps1`의 모듈 순서 `$order`에 새 모듈 추가 필요(현재 content.data, content, meta, save, assets, cloud, economy, ecoui, themes, main). 에셋 경로는 `IMG_BASE + "리터럴"` 형태만 data URI로 바뀜.
- **사용자에게 화면을 보여 줄 때는 PNG 파일로 보낸다(SendUserFile)** — 브라우저 패널의 스크린샷은 사용자에게 안 보인다. 로그인이 필요한 화면(로비)은 로컬 wrangler에 `dist_web/zz_shot.html`(STATUS 00000의 캡처 방법)로 Edge 헤드리스 캡처. 시안은 먼저 HTML 목업(game/zz_*.html, 8796)으로 만들어 PNG로 보여 주고 승인 후 구현(로비는 4판까지 갔음).
- 이 PC에는 git이 없고 프로젝트도 git 저장소가 아니다(백업 = 폴더 + 실서버 배포본). 다른 Claude 세션이 같은 폴더에서 동시에 작업할 수 있으니(포트 8796/8797 점유, index.html·STATUS.md 동시 수정) 편집 전에 파일을 다시 읽을 것.
- QA 훅(콘솔): `__debugAutoPlay(s)`, `__debugAdvance(s)`, `__debugGod=true`, `__debugUnlockAll()`, `__debugSpawn(id,n)`, `__debugForceBoss()`, `__debugBossHp(비율)`, `__debugBossPattern("이름")`, `__debugDecor()`, `__debugPlayerPos()`, `__save()`, `__cloud`. 브라우저 패널은 백그라운드라 게임 루프가 거의 멈추므로 `__debugAdvance`로 시간을 보내고, 이동은 KeyboardEvent를 흉내 낸다.

## 사용자 성향·합의
- 결과를 **실서버에서 바로 확인**하고 스크린샷으로 보여 주면 좋아함. 단일 파일도 매번 첨부해 왔음.
- 배치 변경에 민감: 호야·민지를 "자연스럽게" 바꿨다가 "이전이 낫다"로 되돌림. 큰 재배치 전에 시안 설명 후 진행.
- 이미지는 사용자가 Gemini 앱(구독)으로 생성 → 프롬프트를 복사 가능한 코드 블록으로 요청 문구·파일명·저장 위치까지 적어 주기. API 유료는 원치 않음.
- 도메인 구매는 "나중에 고민". Cloudflare Registrar(.com 약 $10/년) 또는 국내 업체(.kr) 안내함.

## 다음 후보 작업 (우선순위는 사용자에게 확인)
1. **테마 2 「더러워진 개울」** — 테마 1과 같은 절차(그림 8장 → cut → themes.js T2_*). 기획안의 새 기믹(궤적 오염 장판·정지 장애물·이동 안전 구역·인력)은 아직 엔진에 없음. 테마 1 다듬기: 로비 마을 카드(오염/깨끗) 그림, 보스 2페이즈 실제 플레이 확인, 적 이동 애니메이션(2프레임) 원하면 시트 추가 요청.
2. 전투 HUD·결과·레벨업·일시정지 창도 로비처럼 밝은 스타일로. "금화"→"코인" 등 데이터 용어 정리.
3. 학생 비번 재설정/계정 삭제 도구(선생님 전용) — 현재는 D1 쿼리로만 가능.
4. 서바이벌 연출(타이머 경고, 보스 등장 연출).
5. 그림 재생성: 가로 배경 고화질, 엠블럼(여백 있게), 호야 피격 프레임, 민지 점프 최고점 프레임.
6. 도메인 연결(사용자 구매 후).
