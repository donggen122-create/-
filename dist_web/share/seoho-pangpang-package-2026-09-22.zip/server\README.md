# 서호팡팡수호대 서버 (Cloudflare Workers + D1)

게임 본체(`dist_web/`)와 계정·저장 API를 한 Worker로 배포한다. 비용: 무료 요금제(하루 요청 10만, D1 5GB)로 100명 규모 충분.

**현재 배포 주소 (2026-09-22 첫 배포)**: https://seoho-pangpang.seoho-pangpang-server.workers.dev
D1: `seoho-pangpang-db` (APAC, id는 wrangler.toml). 계정: Cloudflare 대시보드 로그인 계정(wrangler login 완료된 PC에서만 배포 가능).

## 구성
- `src/index.js` — `/api/*` 처리(가입·로그인·저장 내려받기/올리기), 그 외 경로는 `dist_web` 정적 파일
- `schema.sql` — D1 테이블(users / sessions / saves / attempts)
- `wrangler.toml` — 배포 설정. `database_id`는 처음 한 번 채워야 한다

## API
| 메서드·경로 | 본문 | 응답 |
|---|---|---|
| GET `/api/health` | – | `{ok:true}` |
| POST `/api/register` | `{id, pw}` | `{token, id, hasSave:false}` |
| POST `/api/login` | `{id, pw}` | `{token, id, hasSave, updatedAt}` |
| GET `/api/me` | (Bearer 토큰) | `{id}` |
| GET `/api/save` | (Bearer) | `{save, updatedAt, device}` |
| PUT `/api/save` | `{save, device}` | `{ok, updatedAt}` |
| POST `/api/logout` | (Bearer) | `{ok}` |

규칙: 아이디 2~12자(한글·영어·숫자·_), 비번 4자 이상. 비번은 PBKDF2-SHA256(12,000회, 사용자별 소금)으로만 저장. 세션 60일.
시도 제한(교실이 공인 IP 하나를 함께 쓰는 점을 고려): IP당 로그인 시도 300회/10분, 가입 100회/시간(안전밸브). 같은 아이디 비밀번호 연속 실패 10회 → 15분 잠금(성공 시 즉시 해제). 값은 `src/index.js`의 `RATE`.

## 처음 배포 (한 번)
PowerShell에서 `server/` 폴더로 이동한 뒤:
```
npx wrangler login                       # 브라우저가 열리면 Cloudflare 계정으로 허용
npx wrangler d1 create seoho-pangpang-db # 출력된 database_id를 wrangler.toml에 붙여 넣기
npx wrangler d1 execute seoho-pangpang-db --remote --file=schema.sql
npx wrangler deploy                      # 주소: https://seoho-pangpang.<계정>.workers.dev
```

## 게임을 고친 뒤 다시 배포
```
Copy-Item ..\game\src\*.js ..\dist_web\src\ -Force; Copy-Item ..\game\index.html ..\dist_web\ -Force
npx wrangler deploy
```

## 로컬 테스트(계정 없이)
```
npx wrangler d1 execute seoho-pangpang-db --local --file=schema.sql
npx wrangler dev --port 8797             # http://localhost:8797 에서 게임+API 동작
```
주의: 로컬 D1은 `wrangler.toml`의 `database_id`별로 따로 생긴다. id를 바꾸면(처음 실제 DB를 만들 때 등) 로컬 DB가 비어 `no such table` 500이 나므로 위 첫 줄을 다시 실행한다. 실서버와는 무관.

## 운영 메모
- 학생이 비번을 잊으면: `npx wrangler d1 execute seoho-pangpang-db --remote --command "DELETE FROM users WHERE id='아이디'"` 후 다시 가입(저장도 함께 삭제되니 주의). 비번 재설정 도구는 필요 시 추가.
- 전체 계정 수: `--command "SELECT COUNT(*) FROM users"`.
