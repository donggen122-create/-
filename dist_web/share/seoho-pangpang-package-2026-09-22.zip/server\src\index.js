// 서호팡팡수호대 저장 서버 — Cloudflare Worker
// 역할: (1) /api/* 계정·저장 API  (2) 그 외 경로는 dist_web 정적 파일(게임 본체)
// 원칙: 개인정보 없음(아이디·비번만). 비번은 PBKDF2 해시로만 보관. 저장 데이터는 사용자당 1개 JSON.

const ID_RE = /^[a-zA-Z0-9가-힣_]{2,12}$/;
const PW_MIN = 4, PW_MAX = 64;
const SAVE_MAX_BYTES = 256 * 1024;                 // 저장 JSON 상한(현재 저장본은 수십 KB)
const SESSION_DAYS = 60;
const PBKDF2_ITER = 12000;                         // Workers 무료 요금제 CPU 한도(10ms) 안에서 도는 수준
// 시도 제한 [횟수, 창(ms)].
// 학교는 교실 전체가 공인 IP 하나를 함께 쓰므로 IP 기준은 '안전밸브' 수준으로 넉넉하게 두고,
// 비밀번호 무차별 대입은 계정 기준(같은 아이디로 연속 실패)으로 막는다. 성공한 로그인은 횟수에 들어가지 않는다.
const RATE = {
  loginIp: [300, 10 * 60_000],       // IP당 로그인 시도 300회/10분 (30명 교실이 여러 번 재시도해도 여유)
  pwFail: [10, 15 * 60_000],         // 같은 아이디 비밀번호 연속 실패 10회 → 15분 잠금(맞게 입력하면 즉시 해제)
  register: [100, 60 * 60_000],      // IP당 가입 100회/시간
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try {
        return withCors(await api(request, env, url));
      } catch (e) {
        console.error("api error", e);
        return withCors(json({ error: "서버에 문제가 생겼어요. 잠시 후 다시 해 주세요." }, 500));
      }
    }
    return env.ASSETS.fetch(request);
  },
};

async function api(request, env, url) {
  const path = url.pathname.replace(/^\/api/, "");
  const method = request.method;
  if (method === "OPTIONS") return new Response(null, { status: 204 });

  if (path === "/health" && method === "GET") return json({ ok: true, ts: Date.now() });

  if (path === "/register" && method === "POST") {
    if (!(await allow(env, "register", ip(request)))) return json({ error: "가입 시도가 너무 많아요. 한 시간 뒤에 다시 해 주세요." }, 429);
    const { id, pw } = await body(request);
    const v = validate(id, pw); if (v) return json({ error: v }, 400);
    const key = id.toLowerCase();
    const exists = await env.DB.prepare("SELECT 1 FROM users WHERE id = ?").bind(key).first();
    if (exists) return json({ error: "이미 있는 아이디예요. 다른 아이디를 골라 주세요." }, 409);
    const salt = randomHex(16);
    const hash = await pbkdf2(pw, salt);
    const now = Date.now();
    await env.DB.prepare("INSERT INTO users (id, display_id, pw_hash, salt, created_at, last_login) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(key, id, hash, salt, now, now).run();
    const token = await newSession(env, key);
    return json({ token, id, hasSave: false });
  }

  if (path === "/login" && method === "POST") {
    if (!(await allow(env, "loginIp", ip(request)))) return json({ error: "로그인 시도가 너무 많아요. 10분 뒤에 다시 해 주세요." }, 429);
    const { id, pw } = await body(request);
    if (typeof id !== "string" || typeof pw !== "string") return json({ error: "아이디와 비밀번호를 입력해 주세요." }, 400);
    const key = id.toLowerCase();
    // 같은 아이디로 비밀번호를 연속으로 틀리면 잠깐 잠근다(무차별 대입 방어). 성공하면 카운터를 지운다.
    if (await isLocked(env, "pwFail", key)) return json({ error: "비밀번호를 여러 번 틀렸어요. 15분 뒤에 다시 해 주세요." }, 429);
    const user = await env.DB.prepare("SELECT id, display_id, pw_hash, salt FROM users WHERE id = ?").bind(key).first();
    const bad = json({ error: "아이디 또는 비밀번호가 맞지 않아요." }, 401);
    if (!user) { await pbkdf2(pw, "00"); await allow(env, "pwFail", key); return bad; }   // 존재 여부를 시간 차로 알 수 없게 같은 계산
    const hash = await pbkdf2(pw, user.salt);
    if (!timingSafeEqual(hash, user.pw_hash)) { await allow(env, "pwFail", key); return bad; }
    await env.DB.prepare("DELETE FROM attempts WHERE key = ?").bind(`pwFail:${key}`).run();
    await env.DB.prepare("UPDATE users SET last_login = ? WHERE id = ?").bind(Date.now(), user.id).run();
    const token = await newSession(env, user.id);
    const save = await env.DB.prepare("SELECT updated_at FROM saves WHERE user_id = ?").bind(user.id).first();
    return json({ token, id: user.display_id, hasSave: !!save, updatedAt: save?.updated_at ?? null });
  }

  // 아래는 로그인 필요
  const user = await auth(request, env);
  if (!user) return json({ error: "다시 접속해 주세요." }, 401);

  if (path === "/me" && method === "GET") return json({ id: user.display_id });

  if (path === "/logout" && method === "POST") {
    await env.DB.prepare("DELETE FROM sessions WHERE token = ?").bind(user.token).run();
    return json({ ok: true });
  }

  if (path === "/save" && method === "GET") {
    const row = await env.DB.prepare("SELECT data, updated_at, device FROM saves WHERE user_id = ?").bind(user.id).first();
    if (!row) return json({ save: null, updatedAt: null });
    return json({ save: JSON.parse(row.data), updatedAt: row.updated_at, device: row.device });
  }

  if (path === "/save" && method === "PUT") {
    const text = await request.text();
    if (text.length > SAVE_MAX_BYTES) return json({ error: "저장 데이터가 너무 커요." }, 413);
    let parsed;
    try { parsed = JSON.parse(text); } catch { return json({ error: "저장 형식이 잘못됐어요." }, 400); }
    if (!parsed || typeof parsed.save !== "object" || parsed.save === null) return json({ error: "저장 형식이 잘못됐어요." }, 400);
    const now = Date.now();
    await env.DB.prepare(
      "INSERT INTO saves (user_id, data, updated_at, device) VALUES (?, ?, ?, ?) " +
      "ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at, device = excluded.device")
      .bind(user.id, JSON.stringify(parsed.save), now, String(parsed.device || "").slice(0, 40)).run();
    return json({ ok: true, updatedAt: now });
  }

  return json({ error: "없는 주소예요." }, 404);
}

// ---------- 도우미 ----------
function validate(id, pw) {
  if (typeof id !== "string" || !ID_RE.test(id)) return "아이디는 2~12자, 한글·영어·숫자·밑줄(_)만 쓸 수 있어요.";
  if (typeof pw !== "string" || pw.length < PW_MIN) return `비밀번호는 ${PW_MIN}자 이상이어야 해요.`;
  if (pw.length > PW_MAX) return "비밀번호가 너무 길어요.";
  return null;
}
async function body(request) {
  try { return await request.json(); } catch { return {}; }
}
function ip(request) { return request.headers.get("CF-Connecting-IP") || "0.0.0.0"; }
// 현재 창 안에서 이미 한도에 닿았는지(횟수를 올리지 않고 확인만)
async function isLocked(env, kind, who) {
  const [max, windowMs] = RATE[kind];
  const row = await env.DB.prepare("SELECT count, window_start FROM attempts WHERE key = ?").bind(`${kind}:${who}`).first();
  return !!row && Date.now() - row.window_start <= windowMs && row.count >= max;
}
// 시도 1회를 기록하고, 한도 안이면 true
async function allow(env, kind, addr) {
  const [max, windowMs] = RATE[kind];
  const key = `${kind}:${addr}`, now = Date.now();
  const row = await env.DB.prepare("SELECT count, window_start FROM attempts WHERE key = ?").bind(key).first();
  if (!row || now - row.window_start > windowMs) {
    await env.DB.prepare("INSERT INTO attempts (key, count, window_start) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = 1, window_start = ?")
      .bind(key, now, now).run();
    return true;
  }
  if (row.count >= max) return false;
  await env.DB.prepare("UPDATE attempts SET count = count + 1 WHERE key = ?").bind(key).run();
  return true;
}
async function auth(request, env) {
  const h = request.headers.get("Authorization") || "";
  const token = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  if (!/^[0-9a-f]{64}$/.test(token)) return null;
  const row = await env.DB.prepare(
    "SELECT s.token, s.expires_at, u.id, u.display_id FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?")
    .bind(token).first();
  if (!row) return null;
  if (row.expires_at < Date.now()) { await env.DB.prepare("DELETE FROM sessions WHERE token = ?").bind(token).run(); return null; }
  return row;
}
async function newSession(env, userId) {
  const token = randomHex(32);
  const expires = Date.now() + SESSION_DAYS * 86400_000;
  await env.DB.prepare("INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)").bind(token, userId, expires).run();
  // 만료된 세션 정리(가끔)
  if (Math.random() < 0.05) await env.DB.prepare("DELETE FROM sessions WHERE expires_at < ?").bind(Date.now()).run();
  return token;
}
function randomHex(nBytes) {
  const a = new Uint8Array(nBytes); crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function pbkdf2(pw, saltHex) {
  const enc = new TextEncoder();
  const keyMat = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  const salt = new Uint8Array(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: PBKDF2_ITER }, keyMat, 256);
  return [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}
// 게임을 다른 주소(예: 로컬 개발 서버)에서 열어도 API를 쓸 수 있게 허용. 토큰 방식이라 쿠키 CSRF 문제 없음.
function withCors(res) {
  const h = new Headers(res.headers);
  h.set("Access-Control-Allow-Origin", "*");
  h.set("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
  h.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  return new Response(res.body, { status: res.status, headers: h });
}
